abstract class AppString {
  static const String home = 'Ev';
  static const String explore = 'Keşfet';
  static const String myList = 'Listem';
  static const String download = 'İndirilenler';
  static const String profile = 'Profil';
  static const String yourListEmpty = 'Liste Boş';
  static const String emptyListMessage =
      'Listeye film eklemediniz.';

  static const String editProfile = 'Profili Düzenle';
  static const String notification = 'Bildirimler';
  static const String security = 'Gizlilik ve Güvenlik';
  static const String darkMode = 'Dark Mode';

  static const String topMoviesThisweek = 'Haftanın En İyi 10 Filmi';

  static const String seeAll = 'Hepsini Gör';
  static const String play = 'Oyna';
  static const String search = 'Ara';
  static const String newReleases = 'Yeni Çıkanlar';
  static const String language = 'Dil';
  static const String helpCenter = 'Yardım Merkezi';
  static const String privacyPolicy = 'Gizlilik Politikası';
  static const String apply = 'Uygula';
  static const String reset = 'Reset';

  static const String sortandFilter = 'Sırala ve Filtrele';

  static const String categories = 'Kategroriler';
  static const String regions = 'Bölgeler';
  static const String genre = 'Tür';

  static const String time = 'Zaman';

  static const String sort = 'Sort';

  static const List<String> moviesCatgories = [
    'Filmler',
    'ABD',
    'Anime',
    'Diziler',
    'Son Çıkanlar'
  ];

  static const List<String> timeAndPeriods = [
    '2024',
    '2023',
    '2022',
    '2021',
    '2020'
  ];

  static const List<String> genreList = [
    'Aksiyon',
    'Macera',
    'Komedi',
    'Korku',
    'Fantastik'
  ];

  static const List<String> regionsList = [
    'Hollywood ',
    'Kanada',
    'Mısır',
    'Türkiye',
    'İspanya',
  ];
}
